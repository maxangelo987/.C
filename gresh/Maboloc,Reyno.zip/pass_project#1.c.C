#include<stdio.h>
#include<string.h>
#include<ctype.h>
main()  {
	char arr[100],phrase[100];
	int x,y,j,k,i,a,z;
	clrscr();
	printf("Enter a phrase:");
	gets(phrase);
	a=strlen(phrase);
	for(i=0;i<a;i++){
		if(isalnum(phrase[i])&&phrase[i+1]==' '){
		y=0;
			for(j=i;;j--){
				if(isalnum(phrase[j])){
				arr[y]=phrase[j];
				y++;}
				else{
				break;}}
				printf("\n");
			for(k=y-1;k>=0;k--){
			printf("%c",arr[k]);}
			if(y%2==0){
			printf("  --->EVEN");}
			else{
			printf("  --->ODD");}}
		if(isalnum(phrase[i])&&phrase[i+1]==NULL){
		x=0;
			for(z=i;;z--){
				if(isalnum(phrase[z])){
				arr[x]=phrase[z];
				x++;}
				else{break;}}
				printf("\n");
			for(k=x-1;k>=0;k--){
			printf("%c",arr[k]);}
			if(x%2==0){
			printf("  --->EVEN");}
			else{
			printf("  --->ODD");}}}
			getch();}



