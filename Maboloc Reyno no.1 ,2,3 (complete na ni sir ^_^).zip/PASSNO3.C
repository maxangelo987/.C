#include<stdio.h>
#include<string.h>
#include<ctype.h>

main(){

	char word_deldel[100],word_del[100],phrase[100],arr[100];

	int a,b,k,i,y,c,count=0,j;
	clrscr();

	printf("Enter a phrase:");
	gets(phrase);
	printf("\nEnter the word to be deleted:");
	gets(word_del);
	strcpy(word_deldel,word_del);
	a=strlen(phrase);
	b=strlen(word_del);
	strrev(word_deldel);

	for(k=0;k<a;k++){
	if (isalnum(phrase[k])&&phrase[k+1]==' '){
		y=0;
		count++;
		for(i=k;;i--){
			if(isalnum(phrase[i])){
			arr[y]=phrase[i];
			y++; }
			else{break;}}
		if(b==y){
		strncpy(word_deldel,arr,b);
		strrev(word_deldel);
		c=strcmpi(word_deldel,word_del);
		if(c!=0){
		for(i=0;i<y;i++){
		if(isalnum(word_deldel[i])){
		printf("%c",word_deldel[i]);}}
		printf(" ");}}

		else{
		for(i=y-1;i>=0;i--){
		if(isalnum(arr[i])){
		printf("%c",arr[i]);}}
		printf(" ");}}
	if(isalnum(phrase[k])&&phrase[k+1]==NULL){
		y=0;      count++;
		for(i=k;;i--){
			if(isalnum(phrase[i])){
			arr[y]=phrase[i];
			y++;}
			else{
			break;}}
		if(b==y){
		strncpy(word_deldel,arr,b);
		strrev(word_deldel);
		c=strcmpi(word_deldel,word_del);
		if(c!=0){
		for(i=y-1;i>=0;i--){
		if(isalnum(word_deldel[i])){
		printf("%c",word_deldel[i]);}}}}
		else{
		for(i=y-1;i>=0;i--){
		if(isalnum(arr[i])){
		printf("%c",arr[i]);}}}}}
		getch();}


